<?php
/*
Template Name: Landing Page
*/
get_header();
?>

<main id="main-content">
    <?
    
    // Example sections — we’ll add them one by one

    ?>
</main>

<?php
get_footer();
?>
